<link href="menu.css" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Questrial' rel='stylesheet'>
   
<nav>
    
<a href="homepage.php" class="logo">Jardin</a>

<ul>
<li><a href="SignIn.php">Sign In</a></li>
<li><a href="Journeys.php">Journeys</a></li>
<li><a href="Calender.php">Calender</a></li>
<li><a href="#">About</a></li>
<li><a href="Contact.php">Contact</a></li>
</ul>
</nav>
