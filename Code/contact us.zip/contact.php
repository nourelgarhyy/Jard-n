
<link href='https://fonts.googleapis.com/css?family=Fira Sans Condensed' rel='stylesheet'>
<link rel="stylesheet" type="text/css" href="https://getbootstrap.com/docs/4.0/components/forms/" />
<link href="contact1.css" rel="stylesheet" type="text/css">
<?php include "menu.php"?>

	<form>
	<h1>	Contact Us  </h1> 
		<div class="form-group">
	  <label for="exampleFormControlInput1">Name</label> <br>
      <input type="text" class="form-control" placeholder=" name">
    </div>
  <div class="form-group">
    <label for="exampleFormControlInput2">Email address</label> <br>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Message</label> <br>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>

 <!-- <img src="contact.png" class="img"> -->

</form>

