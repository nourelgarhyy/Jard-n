<link href="homepage.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Rochester" />
<?php include "menu.php"?>


<header  id="home">
<div class="header-block">
   <img src="header.png">
   <div class="text-block">
    <h4>Where the journey begins</h4><br>
    <p>Jardin is an open-air co-working space, that offers its clients a haven to work and enjoy a day out.
    </p>

  </div>
</div>
</header>